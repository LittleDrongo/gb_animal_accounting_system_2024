# extras

This Maven module contains the source code for supplementary Gson features which
are not included by default.

The artifacts created by this module are currently not deployed to Maven Central.
