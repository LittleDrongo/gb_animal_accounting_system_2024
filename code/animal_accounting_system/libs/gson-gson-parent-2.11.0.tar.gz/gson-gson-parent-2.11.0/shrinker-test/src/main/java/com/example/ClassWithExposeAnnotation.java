package com.example;

import com.google.gson.annotations.Expose;

/** Uses {@link Expose} annotation. */
public class ClassWithExposeAnnotation {
  @Expose int i;

  int i2;
}
