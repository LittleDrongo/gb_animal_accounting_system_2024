package com.example;

public enum EnumClass {
  FIRST,
  SECOND
}
